# 🚀 Guía para Subir tu Sitio Web a tu Servidor

## ✅ Compatibilidad

¡Sí! Tu sitio web es 100% compatible para subir a cualquier servidor. Hay dos opciones según el tipo de servidor que tienes:

---

## 📦 Opción 1: Servidor con Node.js (Recomendado)

### Requisitos del servidor:
- Node.js 16+ instalado
- NPM o Yarn
- Espacio en disco: ~500MB

### Pasos para subir:

#### 1. Preparar los archivos
Descarga estos archivos/carpetas de tu proyecto:
```
/app/frontend/src/          → Todo el código fuente
/app/frontend/public/       → Imágenes y archivos estáticos
/app/frontend/package.json  → Dependencias
/app/frontend/craco.config.js
/app/frontend/tailwind.config.js
```

#### 2. Estructura en tu servidor
```
tu-sitio-web/
├── src/
├── public/
├── package.json
├── craco.config.js
├── tailwind.config.js
└── .env
```

#### 3. Crear archivo .env
Crea un archivo `.env` en la raíz con:
```
REACT_APP_BACKEND_URL=https://tu-dominio.com
PORT=3000
```

#### 4. Instalar dependencias en tu servidor
```bash
cd tu-sitio-web
npm install
# o
yarn install
```

#### 5. Construir para producción
```bash
npm run build
# o
yarn build
```

Esto creará una carpeta `build/` con todos los archivos optimizados.

#### 6. Servir con un servidor web
Puedes usar diferentes opciones:

**Opción A: Servidor Node.js simple**
```bash
npm install -g serve
serve -s build -p 80
```

**Opción B: PM2 (recomendado para producción)**
```bash
npm install -g pm2
pm2 serve build 80 --name "ld-holdings"
pm2 save
pm2 startup
```

---

## 🌐 Opción 2: Servidor Web Tradicional (Apache/Nginx) - MÁS SIMPLE

### Esta es la opción más común y sencilla

#### 1. Construir el sitio
En tu computadora local o en Emergent, ejecuta:
```bash
cd /app/frontend
yarn build
```

Esto creará una carpeta `/app/frontend/build/` con archivos HTML, CSS, JS e imágenes estáticas.

#### 2. Descargar la carpeta build
Descarga todo el contenido de `/app/frontend/build/`

#### 3. Subir a tu servidor
Usando FTP, SFTP, o panel de control (cPanel, Plesk, etc.):
- Sube TODO el contenido de la carpeta `build/` a la carpeta raíz de tu dominio
- Usualmente es: `/public_html/` o `/www/` o `/htdocs/`

#### 4. Configurar el servidor web

**Para Apache (.htaccess):**
Crea un archivo `.htaccess` en la raíz:
```apache
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  RewriteRule ^index\.html$ - [L]
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteCond %{REQUEST_FILENAME} !-l
  RewriteRule . /index.html [L]
</IfModule>

# Configuración de caché
<IfModule mod_expires.c>
  ExpiresActive On
  ExpiresByType image/jpg "access plus 1 year"
  ExpiresByType image/jpeg "access plus 1 year"
  ExpiresByType image/png "access plus 1 year"
  ExpiresByType text/css "access plus 1 month"
  ExpiresByType application/javascript "access plus 1 month"
</IfModule>

# Comprimir archivos
<IfModule mod_deflate.c>
  AddOutputFilterByType DEFLATE text/html text/plain text/xml text/css text/javascript application/javascript
</IfModule>
```

**Para Nginx:**
Agrega esto a tu configuración del sitio:
```nginx
server {
    listen 80;
    server_name tu-dominio.com;
    root /ruta/a/tu/sitio;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    # Caché para archivos estáticos
    location ~* \.(jpg|jpeg|png|gif|ico|css|js)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    # Comprimir archivos
    gzip on;
    gzip_types text/css application/javascript image/svg+xml;
}
```

---

## 📋 Checklist antes de subir

- [ ] Has completado el contenido de todos los servicios
- [ ] Has reemplazado las imágenes placeholder si es necesario
- [ ] Has verificado que todos los enlaces funcionan
- [ ] Has configurado correctamente tu dominio
- [ ] Has hecho backup de tu servidor actual

---

## 🔧 Comandos útiles para generar el build

### Desde Emergent:
```bash
# Generar build de producción
cd /app/frontend
yarn build

# Comprimir para descargar fácilmente
cd /app/frontend
tar -czf ld-holdings-build.tar.gz build/

# El archivo estará en: /app/frontend/ld-holdings-build.tar.gz
```

Luego puedes descargar este archivo y extraerlo en tu servidor.

---

## 🌟 Hostings recomendados (si no tienes servidor)

Si tu servidor actual no funciona bien, estos son excelentes opciones:

### Opciones Gratuitas/Económicas:
1. **Vercel** (Gratis, muy fácil)
2. **Netlify** (Gratis, incluye SSL)
3. **GitHub Pages** (Gratis)
4. **Cloudflare Pages** (Gratis, CDN incluido)

### Opciones Premium:
1. **DigitalOcean** ($5-10/mes)
2. **AWS S3 + CloudFront**
3. **Google Cloud Storage**
4. **Tu hosting actual** (si tiene cPanel/FTP)

---

## ❓ Preguntas Frecuentes

### ¿Necesito base de datos?
No, actualmente el sitio es frontend-only. El formulario de contacto muestra un mensaje en pantalla. Si quieres que envíe emails o guarde en BD, necesitarás backend.

### ¿Funciona con mi dominio actual?
Sí, solo necesitas:
1. Generar el build
2. Subir los archivos a tu servidor
3. Apuntar tu dominio a esa carpeta

### ¿Qué pasa con el formulario de contacto?
Actualmente solo muestra una notificación. Para que funcione completamente, puedo:
- Integrarlo con EmailJS (envío directo de emails)
- Conectarlo a tu backend existente
- Crear un backend simple con Node.js

### ¿Se puede actualizar después?
Sí, cada vez que quieras hacer cambios:
1. Editas los archivos en Emergent o localmente
2. Ejecutas `yarn build`
3. Subes la nueva carpeta build/

---

## 🆘 Si necesitas ayuda

Dime:
- ¿Qué tipo de servidor tienes? (cPanel, VPS, shared hosting)
- ¿Qué panel de control usas?
- ¿Tienes acceso SSH?

Y te ayudo con instrucciones específicas para tu caso.

---

## 🚀 Opción Rápida con GitHub Pages (100% Gratis)

Si quieres algo super rápido:

1. Crea una cuenta en GitHub
2. Crea un repositorio llamado `ld-holdings`
3. Sube la carpeta build/
4. Ve a Settings → Pages
5. Selecciona la rama main
6. ¡Listo! Tu sitio estará en `https://tu-usuario.github.io/ld-holdings`

Luego puedes conectar tu dominio propio desde la configuración.
