#!/bin/bash

# Script para generar build de producción de LD Holdings

echo "🚀 Generando build de producción..."
echo ""

cd /app/frontend

# Limpiar build anterior si existe
if [ -d "build" ]; then
    echo "🗑️  Limpiando build anterior..."
    rm -rf build
fi

# Generar nuevo build
echo "📦 Construyendo aplicación..."
yarn build

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ ¡Build generado exitosamente!"
    echo ""
    echo "📁 Los archivos están en: /app/frontend/build/"
    echo ""
    echo "📊 Tamaño del build:"
    du -sh /app/frontend/build/
    echo ""
    echo "📦 Para descargar fácilmente, se creará un archivo comprimido..."
    
    cd /app/frontend
    tar -czf ld-holdings-build.tar.gz build/
    
    if [ $? -eq 0 ]; then
        echo ""
        echo "✅ Archivo comprimido creado:"
        echo "   📦 /app/frontend/ld-holdings-build.tar.gz"
        ls -lh /app/frontend/ld-holdings-build.tar.gz | awk '{print "   Tamaño:", $5}'
        echo ""
        echo "🎯 Pasos siguientes:"
        echo "   1. Descarga el archivo ld-holdings-build.tar.gz"
        echo "   2. Extrae en tu servidor: tar -xzf ld-holdings-build.tar.gz"
        echo "   3. Sube el contenido de la carpeta build/ a tu servidor web"
        echo ""
        echo "📖 Lee /app/GUIA_DEPLOYMENT.md para más detalles"
    fi
else
    echo "❌ Error al generar el build"
    exit 1
fi
