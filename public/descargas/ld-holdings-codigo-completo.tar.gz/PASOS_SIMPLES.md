# 🎯 PASOS SIMPLES PARA SUBIR TU SITIO A TU SERVIDOR

## ⚡ INSTRUCCIONES RÁPIDAS (5 MINUTOS)

### 📥 PASO 1: Descargar el Archivo

El archivo de tu sitio web está listo aquí:
```
/app/frontend/ld-holdings-build.tar.gz
```

**Tamaño:** 1.8 MB (muy ligero y rápido de descargar)

---

### 🖥️ PASO 2: Subir a Tu Servidor

#### Si tienes cPanel:
1. Entra a cPanel
2. Ve a "Administrador de Archivos" (File Manager)
3. Navega a `public_html/`
4. Haz clic en "Subir" (Upload)
5. Sube el archivo `ld-holdings-build.tar.gz`
6. Haz clic derecho en el archivo → "Extraer" (Extract)
7. Se creará una carpeta llamada `build/`
8. Entra a la carpeta `build/` y selecciona todos los archivos
9. Haz clic en "Mover" (Move) y muévelos a `public_html/`

#### Si tienes acceso FTP (FileZilla):
1. Conecta con tus credenciales FTP
2. Navega a la carpeta `public_html/` o `/www/`
3. Arrastra el archivo `ld-holdings-build.tar.gz`
4. Necesitarás extraerlo por SSH o desde el panel de control

#### Si tienes acceso SSH:
```bash
# Subir el archivo (usando scp desde tu computadora)
scp ld-holdings-build.tar.gz usuario@tu-servidor.com:/home/usuario/

# Conectar por SSH
ssh usuario@tu-servidor.com

# Extraer el archivo
tar -xzf ld-holdings-build.tar.gz

# Mover archivos a la carpeta web
cd build
sudo cp -r * /var/www/html/
# o
sudo cp -r * /public_html/
```

---

### ⚙️ PASO 3: Configurar el Servidor

#### Para Apache (99% de los hostings lo usan):

Crea un archivo llamado `.htaccess` en la raíz de tu sitio con este contenido:

```apache
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  RewriteRule ^index\.html$ - [L]
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteCond %{REQUEST_FILENAME} !-l
  RewriteRule . /index.html [L]
</IfModule>
```

**¿Cómo crear .htaccess en cPanel?**
1. Ve a Administrador de Archivos
2. Haz clic en "+ Archivo" (New File)
3. Nómbralo: `.htaccess`
4. Haz clic derecho → "Editar"
5. Pega el contenido de arriba
6. Guarda

---

### ✅ PASO 4: ¡Listo!

Visita tu dominio: `https://tu-dominio.com`

Tu sitio debería estar funcionando perfectamente 🎉

---

## 🔧 SOLUCIÓN DE PROBLEMAS COMUNES

### ❌ Problema: Página en blanco
**Solución:**
- Verifica que el archivo .htaccess esté en la raíz
- Revisa los permisos: archivos deben tener 644, carpetas 755
- En cPanel: selecciona todos los archivos → "Cambiar permisos"

### ❌ Problema: Error 404 en rutas
**Solución:**
- Asegúrate de que el .htaccess esté presente
- Contacta a tu proveedor para activar mod_rewrite

### ❌ Problema: Imágenes no cargan
**Solución:**
- Verifica que las imágenes estén en la misma carpeta que index.html
- Revisa que los nombres sean exactos: `logo_f.png`, `CEO.png`, `sam.jpeg`, `remodelacion.jpeg`

---

## 🎯 ARCHIVOS QUE DEBERÍAS VER EN TU SERVIDOR

Después de subir, tu carpeta debe tener:

```
public_html/
├── index.html               ← Archivo principal
├── .htaccess                ← Configuración (créalo si no existe)
├── static/
│   ├── css/
│   │   └── main.*.css
│   └── js/
│       └── main.*.js
├── CEO.png
├── sam.jpeg
├── logo.png
├── logo_f.png
├── remodelacion.jpeg
└── asset-manifest.json
```

---

## 📞 INFORMACIÓN DE TU SERVIDOR

**Para completar la configuración, necesitarás:**

- [ ] URL de tu servidor / IP
- [ ] Usuario FTP
- [ ] Contraseña FTP
- [ ] Ruta de la carpeta web (usualmente `/public_html/` o `/www/`)
- [ ] Panel de control (cPanel, Plesk, DirectAdmin, etc.)

---

## 💡 ALTERNATIVA: Hosting Gratuito si tu Servidor no Funciona

Si tienes problemas con tu servidor actual, puedes usar **Netlify** (100% gratis):

1. Ve a [netlify.com](https://netlify.com)
2. Crea una cuenta
3. Arrastra la carpeta `build/` a la ventana
4. ¡Listo! Te dará una URL automática
5. Luego puedes conectar tu dominio propio

**Ventajas:**
- ✅ Gratis para siempre
- ✅ SSL/HTTPS automático
- ✅ CDN global (sitio super rápido)
- ✅ Deploy en 30 segundos
- ✅ Sin configuración técnica

---

## 📊 RESUMEN

| Qué | Dónde | Tamaño |
|-----|-------|--------|
| Archivo para descargar | `/app/frontend/ld-holdings-build.tar.gz` | 1.8 MB |
| Archivos del build | `/app/frontend/build/` | 3.3 MB |
| Documentación | `/app/GUIA_DEPLOYMENT.md` | Completa |

---

## ✨ ÚLTIMO PASO: Probar el Sitio

Después de subir, verifica:
- [ ] La página de inicio carga correctamente
- [ ] El menú de navegación funciona
- [ ] Las imágenes se ven bien
- [ ] El formulario de contacto muestra el mensaje
- [ ] El sitio se ve bien en móvil

---

**¿Necesitas ayuda?** Simplemente dime qué tipo de servidor tienes (cPanel, VPS, shared hosting) y te doy instrucciones específicas.

🚀 ¡Tu sitio está listo para el mundo!
