export const services = [
  {
    id: 1,
    title: 'Asesoría Financiera',
    slug: 'asesoria-financiera',
    description: 'Planificación financiera estratégica para maximizar el crecimiento de tu empresa',
    color: '#87CEEB',
    icon: '📊',
    image: null
  },
  {
    id: 2,
    title: 'Remodelación',
    slug: 'remodelacion',
    description: 'Servicios completos de remodelación para transformar espacios',
    color: '#D4AF37',
    icon: '🏗️',
    image: '/remodelacion.jpeg'
  },
  {
    id: 3,
    title: 'Consultoría Empresarial',
    slug: 'consultoria-empresarial',
    description: 'Asesoría estratégica para optimizar procesos y aumentar la rentabilidad',
    color: '#2E8B57',
    icon: '💼',
    image: null
  },
  {
    id: 4,
    title: 'Gestión de Proyectos',
    slug: 'gestion-proyectos',
    description: 'Administración profesional de proyectos de principio a fin',
    color: '#FF6347',
    icon: '📋',
    image: null
  },
  {
    id: 5,
    title: 'Inversiones',
    slug: 'inversiones',
    description: 'Oportunidades de inversión estratégicas con alto retorno',
    color: '#4682B4',
    icon: '💰',
    image: null
  },
  {
    id: 6,
    title: 'Bienes Raíces',
    slug: 'bienes-raices',
    description: 'Compra, venta y administración de propiedades comerciales y residenciales',
    color: '#8B4513',
    icon: '🏢',
    image: null
  },
  {
    id: 7,
    title: 'Desarrollo Inmobiliario',
    slug: 'desarrollo-inmobiliario',
    description: 'Proyectos de desarrollo inmobiliario de alta calidad',
    color: '#20B2AA',
    icon: '🏗️',
    image: null
  },
  {
    id: 8,
    title: 'Marketing Digital',
    slug: 'marketing-digital',
    description: 'Estrategias digitales para impulsar tu presencia en línea',
    color: '#9370DB',
    icon: '📱',
    image: null
  },
  {
    id: 9,
    title: 'Recursos Humanos',
    slug: 'recursos-humanos',
    description: 'Gestión integral del talento humano en tu organización',
    color: '#DC143C',
    icon: '👥',
    image: null
  },
  {
    id: 10,
    title: 'Tecnología',
    slug: 'tecnologia',
    description: 'Soluciones tecnológicas innovadoras para tu negocio',
    color: '#00CED1',
    icon: '💻',
    image: null
  },
  {
    id: 11,
    title: 'Legal',
    slug: 'legal',
    description: 'Asesoría legal corporativa y empresarial',
    color: '#696969',
    icon: '⚖️',
    image: null
  }
];